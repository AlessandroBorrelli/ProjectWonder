//
//  Famiglia+CoreDataClass.swift
//  AleMockup
//
//  Created by alessandro borrelli on 16/02/22.
//
//

import Foundation
import CoreData


public class Famiglia: NSManagedObject {

}
